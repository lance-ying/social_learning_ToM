// idk which goal should be isolated for s362

import { LevelConfig } from '../types';

export const mod_s362: LevelConfig = {
  id: 'mod_s362',
  name: 'mod_s362',
  asciiMap: `
eWWWWWWWWWb
.WWWWWWWWW.
.WWWWWWWWW.
....M......
WWWW.WWWWWW
WWWW......r
WWWW.WWWWWW
e...ZWWWWWW
WWWW.WWWWWW
...........
WWWRWWWWWWW
WWWBgWWWWWW
`.trim(),
  agentPaths: {
    1: {
      movements: {
        experienced1: { 
          path: ["up", "up", "up", "up", "right", "right", "right", "right", "right", "right", "up", "up", "up", "down", "down", "left", "left", "left", "left", "left", "left", "down", "down", "right", "right", "right", "right", "right", "right", "left", "left", "left", "left", "left", "down", "down", "down", "down", "left", "down", "down", "right"],
          goal: 1,
          type: 'Expert'
        },
        experienced2: { 
          path: ["up", "up", "up", "up", "right", "right", "right", "right", "right", "right", "up", "up", "up", "down", "down", "left", "left", "left", "left", "left", "left", "down", "down", "right", "right", "right", "right", "right", "right", "left", "left", "left", "left", "left", "down", "down", "down", "down", "left", "down", "down", "right"],
          goal: 2,
          type: 'Novice'
        },
        experienced3: { 
          path: ["up", "up", "up", "up", "right", "right", "right", "right", "right", "right", "up", "up", "up", "down", "down", "left", "left", "left", "left", "left", "left", "down", "down", "right", "right", "right", "right", "right", "right", "left", "left", "left", "left", "left", "down", "down", "down", "down", "left", "down", "down", "right"],
          goal: 1,
          type: 'Expert_2'
        },
        experienced4: { 
          path: ["up", "up", "up", "up", "right", "right", "right", "right", "right", "right", "up", "up", "up", "down", "down", "left", "left", "left", "left", "left", "left", "down", "down", "right", "right", "right", "right", "right", "right", "left", "left", "left", "left", "left", "down", "down", "down", "down", "left", "down", "down", "right"],
          goal: 2,
          type: 'Novice_2'
        }
      }
    }
  },
   
  stepsRemaining: 20,
  goal: {
    type: 'B',
    description: 'Find and obtain Treasure B'
  }
};