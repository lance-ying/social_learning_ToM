import { LevelConfig } from '../types';

export const mod_s371: LevelConfig = {
  id: 'mod_s371',
  name: 'mod_s371',
  asciiMap: `
WWWWWWWWWgW
eWWWWWWWWBW
.WWWWWWWW.W
M.........W
.WW.WWWWWWW
bWW.WWWWWWW
WWW.WWWWWWW
WWW.WWWWWWW
..........Z
WWWWWWWWWWW
WWWWWWWWWWW
WWWWWWWWWWW
`.trim(),
  agentPaths: {
    1: {
      movements: {
        experienced1: { 
          path: ["left", "left", "left", "left", "left", "left", "left", "up", "up", "up", "up", "up", "left", "left", "left", "down", "down", "up", "right", "right", "right", "right", "right", "right", "right", "right", "right", "up", "up", "up"],
          goal: 1,
          type: 'Expert'
        },
        experienced2: { 
          path: ["left", "left", "left", "left", "left", "left", "left", "up", "up", "up", "up", "up", "left", "left", "left", "down", "down", "up", "right", "right", "right", "right", "right", "right", "right", "right", "right", "up", "up", "up"],
          goal: 2,
          type: 'Novice'
        },
        experienced3: { 
          path: ["left", "left", "left", "left", "left", "left", "left", "up", "up", "up", "up", "up", "left", "left", "left", "down", "down", "up", "right", "right", "right", "right", "right", "right", "right", "right", "right", "up", "up", "up"],
          goal: 1,
          type: 'Expert_2'
        },
        experienced4: { 
          path: ["left", "left", "left", "left", "left", "left", "left", "up", "up", "up", "up", "up", "left", "left", "left", "down", "down", "up", "right", "right", "right", "right", "right", "right", "right", "right", "right", "up", "up", "up"],
          goal: 2,
          type: 'Novice_2'
        }
      }
    }
  },
    
  stepsRemaining: 45,
  goal: {
    type: 'A',
    description: 'Find and obtain Treasure A'
  }
};