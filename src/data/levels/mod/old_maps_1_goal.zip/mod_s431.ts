import { LevelConfig } from '../types';

export const mod_s431: LevelConfig = {
  id: 'mod_s431',
  name: 'mod_s431',
  asciiMap: `
eWWWWbWWWWW
.WWWW.WWWWW
.WWWW.WWWWW
......WWWWW
.WWWWWWWWWW
Z..........
WWWW.WWWWW.
WWWW.WWWWWe
WWWW.WWWWWW
R....M....r
BWWWWWWWWWW
gWWWWWWWWWW
`.trim(),
  agentPaths: {
    1: {
      movements: {
        experienced1: { 
          path: ["up", "up", "right", "right", "right", "right", "right", "up", "up", "down", "down", "left", "left", "left", "left", "left", "down", "down", "right", "right", "right", "right", "right", "right", "right", "right", "right", "right", "up", "up", "up", "up", "up"],
          goal: 1,
          type: 'Expert'
        },
        experienced2: { 
          path: ["right", "right", "right", "right", "down", "down", "down", "down", "right", "right", "right", "right", "right", "left", "left", "left", "left", "down", "down"],
          goal: 2,
          type: 'Novice'
        },
        experienced3: { 
          path: ["up"],
          goal: 1,
          type: 'Expert_2'
        },
        experienced4: { 
          path: ["right", "right", "right", "right", "down", "down", "down", "down", "right", "right", "right", "right", "right", "left", "left", "left", "left", "down", "down"],
          goal: 2,
          type: 'Novice_2'
        }
      }
    }
  },
  stepsRemaining: 90,
  goal: {
    type: 'B',
    description: 'Find and obtain Treasure B'
  }
};