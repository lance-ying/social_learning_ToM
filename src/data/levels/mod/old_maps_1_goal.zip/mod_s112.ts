import { LevelConfig } from '../types';

export const mod_s112: LevelConfig = {
  id: 'mod_s112',
  name: 'mod_s112',
  asciiMap: `
WWWWWWWWWWW
WeWWWWWg..W
W.WWWWWWW.W
W.........W
WWWWWZWWWWW
We.......eW
WWWWW.WWWWW
WWWWWMWWWWW
WWWWW.WWWWW
W.......BgW
W.WWWWWWWWW
WrWWWWWWWWW
`.trim(),
  agentPaths: {
    1: {
      movements: {
        experienced1: { 
          path: ["up", "right", "right", "right", "right", "up", "up", "left", "left"],
          goal: 1,
          type: 'Expert'
        },
        experienced2: { 
          path: ["up", "right", "right", "right", "right", "up", "up", "left", "left"],
          goal: 2,
          type: 'Novice'
        },
        experienced3: { 
          path: ["up", "right", "right", "right", "right", "up", "up", "left", "left"],
          goal: 1,
          type: 'Expert_2'
        },
        experienced4: { 
          path: ["up", "right", "right", "right", "right", "up", "up", "left", "left"],
          goal: 2,
          type: 'Novice_2'
        }
      }
    }
  },
  stepsRemaining: 70,
  goal: {
    type: 'B',
    description: 'Find and obtain Treasure B'
  }
};
