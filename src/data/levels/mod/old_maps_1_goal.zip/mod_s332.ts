import { LevelConfig } from '../types';

export const mod_s332: LevelConfig = {
  id: 'mod_s332',
  name: 'mod_s332',
  asciiMap: `
WWWWeWWWWWg
WWWW.WWWWWB
b..........
WWW.WWWWWWW
WWW.WWWWWWW
WWWZWWWWWWW
WWW.WWWWWWW
..........r
WWW.WWWWWWW
WWW.WWWWWWW
WWW.WWWWWWW
WWWMWWWWWWW
`.trim(),
  agentPaths: {
    1: {
      movements: {
        experienced1: { 
          path: ["up", "up", "up", "left", "left", "left", "right", "right", "right", "right", "right", "right", "right", "right", "right", "up", "up"],
          goal: 1,
          type: 'Expert'
        },
        experienced2: { 
          path: ["up", "up", "up", "left", "left", "left", "right", "right", "right", "right", "right", "right", "right", "right", "right", "up", "up"],
          goal: 2,
          type: 'Novice'
        },
        experienced3: { 
          path: ["up", "up", "up", "left", "left", "left", "right", "right", "right", "right", "right", "right", "right", "right", "right", "up", "up"],
          goal: 1,
          type: 'Expert_2'
        },
        experienced4: { 
          path: ["up", "up", "up", "left", "left", "left", "right", "right", "right", "right", "right", "right", "right", "right", "right", "up", "up"],
          goal: 2,
          type: 'Novice_2'
        }
      }
    }
  },

  stepsRemaining: 40,
  goal: {
    type: 'A',
    description: 'Find and obtain Treasure A'
  }
};