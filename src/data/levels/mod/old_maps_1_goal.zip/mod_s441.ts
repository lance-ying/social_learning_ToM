import { LevelConfig } from '../types';

export const mod_s441: LevelConfig = {
  id: 'mod_s441',
  name: 'mod_s441',
  asciiMap: `
gWWWWWWWeWW
.WWWWWWW.WW
BWWWWWWW.WW
.....M....e
WWWWW.WW.WW
WWWWW.WW.WW
WWWWW.WW.WW
r....ZWW..e
WWWWW.WW.WW
...........
.WWWWWWW.WW
eWWWWWWWbWW
`.trim(),
  agentPaths: {
    1: {
      movements: {
        experienced1: { 
          path: ["down", "down", "right", "right", "right", "down", "up", "right", "right", "down", "down"],
          goal: 1,
          type: 'Expert'
        },
        experienced2: { 
          path: ["up", "up", "up", "up", "up", "up", "up"],
          goal: 2,
          type: 'Novice'
        },
        experienced3: { 
          path: ["up"],
          goal: 1,
          type: 'Expert_2'
        },
        experienced4: { 
          path: ["up", "up", "up", "up", "up", "up", "up", "up"],
          goal: 2,
          type: 'Novice_2'
        }
      }
    }
  },
  stepsRemaining: 65,
  goal: {
    type: 'A',
    description: 'Find and obtain Treasure A'
  }
};