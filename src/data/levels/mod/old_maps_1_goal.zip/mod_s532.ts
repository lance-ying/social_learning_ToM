import { LevelConfig } from '../types';

export const mod_s532: LevelConfig = {
  id: 'mod_s532',
  name: 'mod_s532',
  asciiMap: `
eWWWe.....b
.WWWWWW.WWW
.WWWWWW.WWW
.......Z..e
WWWWW.WWWWW
WWWWW......
WWWWW.WWWWW
WWWWWMWWWWW
WWWWW.WWWWW
.........Bg
.WWWWWWWWWW
rWWWWWWWWWW
`.trim(),
  agentPaths: {
    1: {
      movements: {
        experienced1: { 
          path: ["up", "up", "up", "right", "right", "left", "left", "down", "down", "down", "left", "left", "down", "down", "down", "down", "down", "down", "right", "right", "right", "right", "right"],
          goal: 1,
          type: 'Expert'
        },
        experienced2: { 
          path: ["left", "left", "down", "down", "left", "left", "left", "left", "left"],
          goal: 2,
          type: 'Novice'
        },
        experienced3: { 
          path: ["up"],
          goal: 1,
          type: 'Expert_2'
        },
        experienced4: { 
          path: ["up", "up", "up", "right", "right", "left", "left", "down", "down", "down", "left", "left", "down", "down", "down", "down", "down", "down", "down", "down"],
          goal: 2,
          type: 'Novice_2'
        }
      }
    }
  },
  stepsRemaining: 65,
  goal: {
    type: 'B',
    description: 'Find and obtain Treasure B'
  }
};