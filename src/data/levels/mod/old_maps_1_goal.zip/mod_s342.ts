import { LevelConfig } from '../types';

export const mod_s342: LevelConfig = {
  id: 'mod_s342',
  name: 'mod_s342',
  asciiMap: `
WWWWWrWWWWW
eWWWW.WWWWW
.WWWW.WWWWW
..Z.......W
.WW.WWW.WWW
bWW.WWW.WWW
WWW.WWW.WWW
WWW.WWW.WWW
..........M
WWWWWRWWWWW
WWWWWBWWWWW
WWWWWgWWWWW
`.trim(),
  agentPaths: {
    1: {
      movements: {
        experienced1: { 
          path: ["left", "left", "down", "down", "up", "right", "right", "right", "right", "right", "up", "up", "up", "down", "down", "left", "left", "down", "down", "down", "down", "down", "right", "right", "down", "down", "down"],
          goal: 1,
          type: 'Expert'
        },
        experienced2: { 
          path: ["left", "left", "down", "down", "up", "right", "right", "right", "right", "right", "up", "up", "up", "down", "down", "left", "left", "down", "down", "down", "down", "down", "right", "right", "down", "down", "down"],
          goal: 2,
          type: 'Novice'
        },
        experienced3: { 
          path: ["left", "left", "down", "down", "up", "right", "right", "right", "right", "right", "up", "up", "up", "down", "down", "left", "left", "down", "down", "down", "down", "down", "right", "right", "down", "down", "down"],
          goal: 1,
          type: 'Expert_2'
        },
        experienced4: { 
          path: ["left", "left", "down", "down", "up", "right", "right", "right", "right", "right", "up", "up", "up", "down", "down", "left", "left", "down", "down", "down", "down", "down", "right", "right", "down", "down", "down"],
          goal: 2,
          type: 'Novice_2'
        }
      }
    }
  },

  stepsRemaining: 80,
  goal: {
    type: 'B',
    description: 'Find and obtain Treasure B'
  }
};