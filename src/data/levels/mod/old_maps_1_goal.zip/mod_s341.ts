import { LevelConfig } from '../types';

export const mod_s341: LevelConfig = {
  id: 'mod_s341',
  name: 'mod_s341',
  asciiMap: `
WWWWWrWWWWW
eWWWW.WWWWW
.WWWW.WWWWW
......Z...W
.WW.WWWWWWW
bWW.WWWWWWW
WWW.WWWWWWW
WWW.WWWWWWW
..........M
WWWWW.WWWWW
WWWWWBWWWWW
WWWWWgWWWWW
`.trim(),
  agentPaths: {
    1: {
      movements: {
        experienced1: { 
          path: ["left", "left", "left", "left", "left", "left", "down", "down", "up", "right", "right", "right", "down", "down", "down", "down", "down", "right", "right", "down", "down", "down"],
          goal: 1,
          type: 'Expert'
        },
        experienced2: { 
          path: ["left", "left", "left", "left", "left", "left", "down", "down", "up", "right", "right", "right", "down", "down", "down", "down", "down", "right", "right", "down", "down", "down"],
          goal: 2,
          type: 'Novice'
        },
        experienced3: { 
          path: ["left", "left", "left", "left", "left", "left", "down", "down", "up", "right", "right", "right", "down", "down", "down", "down", "down", "right", "right", "down", "down", "down"],
          goal: 1,
          type: 'Expert_2'
        },
        experienced4: { 
          path: ["left", "left", "left", "left", "left", "left", "down", "down", "up", "right", "right", "right", "down", "down", "down", "down", "down", "right", "right", "down", "down", "down"],
          goal: 2,
          type: 'Novice_2'
        }
      }
    }
  },

  stepsRemaining: 70,
  goal: {
    type: 'B',
    description: 'Find and obtain Treasure B'
  }
};